```
./build_conda.sh 3.9 2.0.0 cu117  # python, pytorch and cuda version
```
